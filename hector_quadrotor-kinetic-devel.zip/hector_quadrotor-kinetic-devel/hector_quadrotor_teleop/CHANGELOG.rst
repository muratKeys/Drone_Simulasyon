^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package hector_quadrotor_teleop
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.3.5 (2015-03-28)
------------------

0.3.4 (2015-02-22)
------------------
* Add optional parameter to set the joystick device
* Contributors: whoenig

0.3.3 (2014-09-01)
------------------
* added run dependency to joy package (joystick drivers)
* Contributors: Johannes Meyer

0.3.2 (2014-03-30)
------------------

0.3.1 (2013-12-26)
------------------
* added slow button (btn 6 on Logitech Gamepad)
* Contributors: Johannes Meyer

0.3.0 (2013-09-11)
------------------
* Catkinized stack hector_quadrotor and integrated hector_quadrotor_demo package from former hector_quadrotor_apps stack
* decreased z_velocity_max to 2.0 m/s in logitech_gamepad.launch
